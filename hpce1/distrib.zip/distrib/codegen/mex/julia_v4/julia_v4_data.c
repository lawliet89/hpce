/*
 * julia_v4_data.c
 *
 * Code generation for function 'julia_v4_data'
 *
 * C source code generated on: Tue Feb 04 15:52:20 2014
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "julia_v4.h"
#include "julia_v4_data.h"

/* Variable Definitions */
emlrtMCInfo emlrtMCI = { 7, 5, "julia_v4",
  "D:/Dropbox/School Work/HPCE/HPCE1/distrib/q6/julia_v4.m" };

/* End of code generation (julia_v4_data.c) */
