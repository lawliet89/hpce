% Plot graphs

xLimit = [2^8 2^20];

% Comparison of scalar vs vector vs compiled in non parallerised
[tOriginal, pixels] = time_renderer(rjv2(@julia_v1));
tVector = time_renderer(rjv2(@julia_v2));
tCompile = time_renderer(rjv2(@julia_v4_mex));

figure;
loglog(pixels, tOriginal, pixels, tVector, pixels, tCompile);
xlim(xLimit);
xlabel('Frame Pixel Count');
ylabel('Running Time/s');
legend('Scalar', 'Vectorised', 'Compiled Scalar');
title('Comparison of `julia` running sequentially');
grid on;

% Comparison of scalar vs vector compiled parallerised
figure(2);
tpOriginal = time_renderer(rjv2(@julia_v1, @render_julia_v2));
tpVector = time_renderer(rjv2(@julia_v2, @render_julia_v2));
tpCompile = time_renderer(rjv2(@julia_v4_mex, @render_julia_v2));

loglog(pixels, tpOriginal, pixels, tpVector, pixels, tpCompile);
xlim(xLimit);
xlabel('Frame Pixel Count');
ylabel('Running Time/s');
legend('Scalar','Vectorised', 'Compiled Scalar');
title('Comparison of `julia` running in parallel');
grid on;

% Comparison of parallerised vs parallerised using scalar
figure(3);

loglog(pixels, tOriginal, pixels, tpOriginal);
xlim(xLimit);
xlabel('Frame Pixel Count');
ylabel('Running Time/s');
legend('Sequential', 'Parallerised');
title('Comparison of scalar calculation sequentially vs parallerised');
grid on;

% Comparison of parallerised vs parallerised using vectorised
figure(4);

loglog(pixels, tVector, pixels, tpVector);
xlim(xLimit);
xlabel('Frame Pixel Count');
ylabel('Running Time/s');
legend('Sequential', 'Parallerised');
title('Comparison of vectorised calculation sequentially vs parallerised');
grid on;


% Comparison of parallerised vs parallerised using compiled
figure(5);

loglog(pixels, tCompile, pixels, tpCompile);
xlim(xLimit);
xlabel('Frame Pixel Count');
ylabel('Running Time/s');
legend('Sequential', 'Parallerised');
title('Comparison of compiled calculation sequentially vs parallerised');
grid on;